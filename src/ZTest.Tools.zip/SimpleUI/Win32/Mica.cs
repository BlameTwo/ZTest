﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace SimpleUI.Win32 {
    public static class Mica {
        [DllImport("dwmapi.dll")]
        public static extern int DwmSetWindowAttribute(IntPtr hwnd, DwmWindowAttribute dwAttribute, ref int pvAttribute, int cbAttribute);
    }

    public enum WindowCompositionAttribute {
        WCA_ACCENT_POLICY = 19
    }

    [Flags]
    public enum DwmWindowAttribute : uint {
        DWMWA_USE_IMMERSIVE_DARK_MODE = 0x14u,
        DWMWA_MICA_EFFECT = 0x405u
    }

    public struct WindowCompositionAttributeData {
        public WindowCompositionAttribute Attribute;

        public IntPtr Data;

        public int SizeOfData;
    }

    public enum AccentState {
        ACCENT_DISABLED = 1,
        ACCENT_ENABLE_GRADIENT = 0,
        ACCENT_ENABLE_TRANSPARENTGRADIENT = 2,
        ACCENT_ENABLE_BLURBEHIND = 3,
        ACCENT_INVALID_STATE = 4
    }

    public struct AccentPolicy {
        public AccentState AccentState;

        public int AccentFlags;

        public int GradientColor;

        public int AnimationId;
    }
}

﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Interop;
using System.Windows;

namespace SimpleUI.Win32;
public static class CornerRadius {
    public enum DWMWINDOWATTRIBUTE {
        DWMWA_WINDOW_CORNER_PREFERENCE = 33
    }

    public enum DWM_WINDOW_CORNER_PREFERENCE {
        DWMWCP_DEFAULT,
        DWMWCP_DONOTROUND,
        DWMWCP_ROUND,
        DWMWCP_ROUNDSMALL
    }

    [DllImport("dwmapi.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern long DwmSetWindowAttribute(IntPtr hwnd, DWMWINDOWATTRIBUTE attribute, ref DWM_WINDOW_CORNER_PREFERENCE pvAttribute, uint cbAttribute);

    public static void SetCornerRadius(Window win, DWM_WINDOW_CORNER_PREFERENCE dwm) {
        WindowInteropHelper windowInteropHelper = new WindowInteropHelper(win);
        IntPtr handle = windowInteropHelper.Handle;
        DWMWINDOWATTRIBUTE attribute = DWMWINDOWATTRIBUTE.DWMWA_WINDOW_CORNER_PREFERENCE;
        DWM_WINDOW_CORNER_PREFERENCE dWM_WINDOW_CORNER_PREFERENCE = dwm;
        DwmSetWindowAttribute(handle, attribute, ref dwm, 4u);
    }
}

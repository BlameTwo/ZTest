﻿using System;
using System.Runtime.InteropServices;
using static SimpleUI.Utils.WindowBackdropBase.BackgroundEnum;

namespace SimpleUI.Win32 {
    public static class Win32 {
        public const int WS_MINIMIZEBOX = 131072;

        public const int WS_MAXIMIZEBOX = 65536;

        public const int WS_EXIT = 0x80000;

        public const int WS_SYSMENU = 524288;


        public const int GWL_STYLE = -16;

        public const int SW_SHOWNORMAL = 1;

        public const int SC_CLOSE = 61536;

        public const int MF_ENABLED = 0;

        public const int MF_GRAYED = 1;

        public const int MF_DISABLED = 2;

        [DllImport("user32.dll", SetLastError = true)]
        public static extern int GetWindowLong(IntPtr hWnd, int nIndex);

        [DllImport("user32")]
        public static extern uint SetWindowLong(IntPtr hwnd, int nIndex, int NewLong);

        [DllImport("user32.dll")]
        public static extern bool EnableMenuItem(IntPtr hMenu, int uIDEnableItem, int uEnable);

        [DllImport("user32.dll")]
        public static extern IntPtr GetSystemMenu(IntPtr hWnd, int bRevert);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern int SetWindowText(IntPtr hwnd, string lpString);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern bool ShowWindow(IntPtr hWnd, short State);

        [DllImport("user32.dll")]
        private static extern int SetWindowCompositionAttribute(IntPtr hwnd, ref WindowCompositionAttributeData data);

        [DllImport("dwmapi.dll")]
        private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int attrValue, int attrSize);

        [DllImport("dwmapi.dll")]
        private static extern int DwmExtendFrameIntoClientArea(IntPtr hWnd, ref MARGINS pMarInset);

        public static void EnableBlur(IntPtr hwind) {
            try {
                AccentPolicy structure = default(AccentPolicy);
                int num = Marshal.SizeOf(structure);
                structure.AccentState = AccentState.ACCENT_ENABLE_BLURBEHIND;
                IntPtr intPtr = Marshal.AllocHGlobal(num);
                Marshal.StructureToPtr(structure, intPtr, fDeleteOld: false);
                WindowCompositionAttributeData windowCompositionAttributeData = default(WindowCompositionAttributeData);
                windowCompositionAttributeData.Attribute = WindowCompositionAttribute.WCA_ACCENT_POLICY;
                windowCompositionAttributeData.SizeOfData = num;
                windowCompositionAttributeData.Data = intPtr;
                WindowCompositionAttributeData data = windowCompositionAttributeData;
                SetWindowCompositionAttribute(hwind, ref data);
                Marshal.FreeHGlobal(intPtr);
            }
            catch (Exception) {
            }
        }
    }
}

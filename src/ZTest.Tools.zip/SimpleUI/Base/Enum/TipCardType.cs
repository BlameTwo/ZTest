﻿namespace SimpleUI.Base.Enum; 

/// <summary>
/// 提示卡片的显示属性
/// </summary>
public enum TipCardType {
    Warning,Error,Sucess,Default
}

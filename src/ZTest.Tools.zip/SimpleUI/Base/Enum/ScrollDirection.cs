﻿namespace SimpleUI.Base.Enum;

public enum ScrollDirection
{
    Vertical,
    Horizontal
}

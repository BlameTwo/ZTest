﻿namespace SimpleUI.Base.Enum;

public enum ImageAnimationType
{
    Opacity,Default,XYO
}

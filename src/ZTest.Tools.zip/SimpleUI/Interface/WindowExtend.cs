﻿namespace SimpleUI.Interface
{
    public class WindowExtend
    {

    }
}
